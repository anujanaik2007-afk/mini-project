# My Portfolio

A minimal portfolio site (HTML + CSS, no build step).

## Use it
1. Open `index.html` and replace "Your Name", the projects and the links.
2. Upload this folder's files to a GitHub repo named `your-username.github.io`.
3. Live at `https://your-username.github.io` in a minute or two.
